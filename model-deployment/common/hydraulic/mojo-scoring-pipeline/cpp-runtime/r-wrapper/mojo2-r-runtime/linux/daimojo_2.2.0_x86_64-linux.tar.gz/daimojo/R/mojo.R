# Copyright © 2018 - 2019 H2O.AI Inc. All rights reserved.

setClass("mojo", representation(backend="C++Object"))

load.mojo <- function(filnename) {
  if (!file.exists(filnename)) {
    stop("File ", filnename, " not found")
  }
  filnename <- path.expand(filnename)

  m <- new(rcppmojo, filnename, system.file("lib", package="daimojo"))
  
  if (!m$is_valid()) {
    stop("No valid Driverless AI license!")
  }
  
  return(new("mojo", backend=m))
}

create.time <-function(m) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  return(as.POSIXct(m@backend$created_time(), origin="1970-01-01"))
}

uuid <- function(m) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  return(m@backend$uuid())
}

feature.names <- function(m) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  return(m@backend$feature_names())
}

feature.types <- function(m) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  feature_types <- m@backend$feature_types()
  return(feature_types)
}

output.names <- function(m) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  return(m@backend$output_names())
}

output.types <- function(m) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  output_types <- m@backend$output_types()
  return(output_types)
}

predict.mojo <- function(m, newdata) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!inherits(newdata, "data.frame")) {
    stop("newdata must be a data.frame")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  feature_names <- feature.names(m)
  feature_types <- feature.types(m)
  
  newdata <- subset(newdata, ,feature_names)

  for (idx in 1:length(feature_names)) {
    idx <- as.integer(idx)
    if (feature_types[idx] != typeof(newdata[[idx]])) {
      warning(paste("mojo expects col '", feature_names[idx], "' to be ", feature_types[idx],
                    ",", " but ", typeof(newdata[[idx]]), " found.", sep = ""))
      if (feature_types[idx] == "double") {
        newdata[[idx]] <- as.double(newdata[[idx]])
      } else if (feature_types[idx] == "character") {
        newdata[[idx]] <- as.character(newdata[[idx]])
      } else if (feature_types[idx] == "integer") {
        newdata[[idx]] <- as.integer(newdata[[idx]])
      }
    }
  }
  
  return(m@backend$predict(newdata))
}

missing.values <- function(m) {
  if (class(m) != "mojo") {
    stop("not a mojo object!")
  }

  if (!m@backend$is_valid()) {
    stop("No valid Driverless AI license!")
  }

  return(m@backend$missing_values())
}

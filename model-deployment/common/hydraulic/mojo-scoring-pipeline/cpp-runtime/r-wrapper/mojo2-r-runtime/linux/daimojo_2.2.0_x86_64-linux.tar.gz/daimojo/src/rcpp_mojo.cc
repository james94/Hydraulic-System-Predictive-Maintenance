// Copyright 2018-2019 H2O.AI, Inc. All Rights Reserved.

#include <Rcpp.h>
#include <stdio.h>
#include <stdlib.h>
#include "c_api.h"

static inline std::string mojo_data_type_to_r_type(MOJO_DataType type) {
  switch (type) {
    case MOJO_UNKNOWN:
      return "unknown";
    case MOJO_FLOAT:
    case MOJO_DOUBLE:
      return "double";
    case MOJO_INT32:
    case MOJO_INT64:
      return "integer";
    case MOJO_STRING:
      return "character";
  }
  return "unknown";
}

class Mojo {
 public:
  Mojo(const std::string& filename, const std::string& tf_lib_prefix) {
    model_ = MOJO_NewModel(filename.c_str(), tf_lib_prefix.c_str());
    feature_num_ = MOJO_FeatureNum(model_);
    feature_names_.resize(feature_num_);
    feature_types_.resize(feature_num_);
    c_feature_names_ = MOJO_FeatureNames(model_);
    c_feature_types_ = MOJO_FeatureTypes(model_);
    for (size_t k = 0; k < feature_num_; ++k) {
      feature_names_[k] = std::string(c_feature_names_[k]);
      feature_types_[k] = mojo_data_type_to_r_type(c_feature_types_[k]);
    }

    output_num_ = MOJO_OutputNum(model_);
    output_names_.resize(output_num_);
    output_types_.resize(output_num_);
    char** c_output_names = MOJO_OutputNames(model_);
    c_output_types_ = MOJO_OutputTypes(model_);
    for (size_t k = 0; k < output_num_; ++k) {
      output_names_[k] = std::string(c_output_names[k]);
      output_types_[k] = mojo_data_type_to_r_type(c_output_types_[k]);
      free(c_output_names[k]);
    }
    free(c_output_names);
    size_t missing_values_num = MOJO_MissingValuesNum(model_);
    char** c_missing_values = MOJO_MissingValues(model_);
    missing_values_.resize(missing_values_num);
    for (size_t k = 0; k < missing_values_num; ++k) {
      missing_values_[k] = std::string(c_missing_values[k]);
      free(c_missing_values[k]);
    }
    free(c_missing_values);

    char * c_uuid = MOJO_UUID(model_);
    uuid_ = std::string(c_uuid);
    free(c_uuid);
  }

  Rcpp::DataFrame predict(const Rcpp::DataFrame& data) {
    size_t nrow = data.nrow();
    MOJO_Col** cols = (MOJO_Col**)malloc(sizeof(MOJO_Col*) * feature_num_);
    for (size_t k = 0; k < feature_num_; ++k) {
      SEXP input_k = data[feature_names_[k]];
      switch (c_feature_types_[k]) {
        case MOJO_UNKNOWN: {
          Rcpp::Rcerr << "unknown data type found" << std::endl;
          break;
        }
        case MOJO_FLOAT: {
          std::vector<double> double_data = Rcpp::as<std::vector<double> >(input_k);
          std::vector<float> float_data(double_data.begin(), double_data.end());
          cols[k] = MOJO_NewCol(c_feature_types_[k], nrow, float_data.data());
          break;
        }
        case MOJO_DOUBLE: {
          std::vector<double> double_data = Rcpp::as<std::vector<double> >(input_k);
          cols[k] = MOJO_NewCol(c_feature_types_[k], nrow, double_data.data());
          break;
        }
        case MOJO_INT32: {
          std::vector<int> int_data = Rcpp::as<std::vector<int> >(input_k);
          cols[k] = MOJO_NewCol(c_feature_types_[k], nrow, int_data.data());
          break;
        }
        case MOJO_INT64: {
          std::vector<int> int_data = Rcpp::as<std::vector<int> >(input_k);
          std::vector<int64_t> int64_data(int_data.begin(), int_data.end());
          cols[k] = MOJO_NewCol(c_feature_types_[k], nrow, int64_data.data());
          break;
        }
        case MOJO_STRING: {
          std::vector<std::string> str_data = Rcpp::as<std::vector<std::string> >(input_k);
          const char** c_str_data = new const char*[nrow];
          for (size_t i = 0; i < nrow; ++i) {
            c_str_data[i] = str_data[i].c_str();
          }
          cols[k] = MOJO_NewCol(c_feature_types_[k], nrow, c_str_data);
          delete[] c_str_data;
          break;
        }
      }
    }

    frame_ = MOJO_NewFrame(cols, (const char**)c_feature_names_, feature_num_);

    for (size_t k = 0; k < feature_num_; ++k) {
      MOJO_DeleteCol(cols[k]);
    }
    free(cols);

    MOJO_Predict(model_, frame_);

    Rcpp::List res(output_names_.size());
    for (size_t k = 0; k < output_num_; ++k) {
      MOJO_Col* output_k = MOJO_GetColByName(frame_, output_names_[k].c_str());
      switch (c_output_types_[k]) {
        case MOJO_UNKNOWN: {
          Rcpp::Rcerr << "unknown data found" << std::endl;
          break;
        }
        case MOJO_FLOAT: {
          std::vector<double> d(nrow);
          float* data_k = (float*)MOJO_Data(output_k);
          for (size_t i = 0; i < d.size(); ++i) {
            d[i] = data_k[i];
          }
          free(data_k);
          res[k] = Rcpp::wrap(d);
          break;
        }
        case MOJO_DOUBLE: {
          std::vector<double> d(nrow);
          double* data_k = (double*)MOJO_Data(output_k);
          for (size_t i = 0; i < d.size(); ++i) {
            d[i] = data_k[i];
          }
          free(data_k);
          res[k] = Rcpp::wrap(d);
          break;
        }
        case MOJO_INT32: {
          std::vector<int32_t> d(nrow);
          int32_t* data_k = (int32_t*)MOJO_Data(output_k);
          for (size_t i = 0; i < d.size(); ++i) {
            d[i] = data_k[i];
          }
          free(data_k);
          res[k] = Rcpp::wrap(d);
          break;
        }
        case MOJO_INT64: {
          std::vector<int64_t> d(nrow);
          int64_t* data_k = (int64_t*)MOJO_Data(output_k);
          for (size_t i = 0; i < d.size(); ++i) {
            d[i] = data_k[i];
          }
          free(data_k);
          res[k] = Rcpp::wrap(d);
          break;
        }
        case MOJO_STRING: {
          SEXP out = PROTECT(Rf_allocVector(STRSXP, nrow));
          char** data_k = (char**)MOJO_Data(output_k);
          for (size_t i = 0; i < nrow; ++i) {
            SET_STRING_ELT(out, i, Rf_mkChar(data_k[i]));
          }
          free(data_k);
          UNPROTECT(1);
          res[k] = out;
          break;
        }
      }
      MOJO_DeleteCol(output_k);
    }

    res.attr("names") = output_names_;
    return res;
  }

  std::vector<std::string> missing_values() { return missing_values_; }

  std::vector<std::string> feature_names() { return feature_names_; }

  std::vector<std::string> feature_types() { return feature_types_; }

  std::vector<std::string> output_names() { return output_names_; }

  std::vector<std::string> output_types() { return output_types_; }

  bool is_valid() { return MOJO_IsValid(model_); }

  int64_t created_time() { return MOJO_TimeCreated(model_); }

  std::string uuid() {return uuid_;}

  ~Mojo() {
    MOJO_DeleteFrame(frame_);
    MOJO_DeleteModel(model_);
    free(c_feature_types_);
    free(c_output_types_);
    for (size_t k = 0; k < feature_num_; ++k) {
      free(c_feature_names_[k]);
    }
    free(c_feature_names_);
  }

 private:
  MOJO_Frame* frame_;

  MOJO_Model* model_;

  char ** c_feature_names_;

  std::vector<std::string> feature_names_, output_names_;

  std::vector<std::string> feature_types_, output_types_;

  size_t feature_num_, output_num_;

  std::vector<std::string> missing_values_;

  MOJO_DataType *c_feature_types_, *c_output_types_;

  std::string uuid_;
};

RCPP_MODULE(rcppmojo) {
  using namespace Rcpp;

  class_<Mojo>("rcppmojo")
      .constructor<std::string, std::string>()
      .method("is_valid", &Mojo::is_valid)
      .method("created_time", &Mojo::created_time)
      .method("missing_values", &Mojo::missing_values)
      .method("uuid", &Mojo::uuid)
      .method("feature_names", &Mojo::feature_names)
      .method("feature_types", &Mojo::feature_types)
      .method("output_names", &Mojo::output_names)
      .method("output_types", &Mojo::output_types)
      .method("predict", &Mojo::predict);
}

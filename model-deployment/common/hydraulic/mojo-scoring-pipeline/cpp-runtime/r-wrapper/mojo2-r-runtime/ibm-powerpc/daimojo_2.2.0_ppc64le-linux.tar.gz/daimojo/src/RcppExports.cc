// Copyright 2018-2019 H2O.AI, Inc. All Rights Reserved.

#include <Rcpp.h>

using namespace Rcpp;

RcppExport SEXP _rcpp_module_boot_rcppmojo();

static const R_CallMethodDef CallEntries[] = {
    {"_rcpp_module_boot_rcppmojo", (DL_FUNC)&_rcpp_module_boot_rcppmojo, 0},
    {NULL, NULL, 0}};

RcppExport void R_init_daimojo(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
